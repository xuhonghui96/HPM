function [X, Out_tSVD_FFDnet] = admm_HPM(Xmiss,Omega,opts)
addpath(genpath('TV_operator'));
global sigmas
minsigma = 0.01;
decfac = 0.9;
gamma = 0.1 ;
[w, h, c] = size(Xmiss);
tau    = 0.001 *sqrt(w*h);
lambdaInit = 0.05; 
lambda = 0.2;
transform.L = @dct; transform.l = 1; transform.inverseL = @idct;
%    transform.L = @fft; transform.l = c; transform.inverseL = @ifft;

if isfield(opts,'sigma');       sigma = opts.sigma;                  else  sigma = 0.01;                end
% if isfield(opts,'lambda');       lambda = opts.lambda;                  else  lambda = 0.05;                end
if isfield(opts,'beta1');       beta1 = opts.beta1;                  else  beta1 = 1e-2;                end
if isfield(opts,'beta2');       beta2 = opts.beta2;                  else  beta2 = 1e-2;                end

if isfield(opts,'maxit');      maxit = opts.maxit;      else   maxit=200;     end
if isfield(opts,'tol');       tol= opts.tol;                  else  tol = 1e-4;                end

if isfield(opts,'rho');       rho= opts.rho;                  else  rho = 1.04;                end
if isfield(opts,'maxbeta');       maxbeta= opts.maxbeta;                  else  maxbeta = 10000;                end
if isfield(opts,'debug');       debug= opts.debug;                  else  debug = 0;                end
Xtrue = opts.Xtrue;
useGPU      = 1;
max_mu  = 10e5;
mu      = 1e-2;
rho1     = 1.04;
%% initialization
X = rand(size(Xmiss));
X(Omega) = Xmiss(Omega);
W               = X;
Lambda1 = zeros(size(X));
Lambda2 = zeros(size(X));
Lambda3 = zeros(size(X));
beta3=beta1;
beta4=beta1;
sizeD           = size(X);
n               = prod(sizeD);
F               = ((zeros(3*n,1)));     % F : auxiliary variable for tv
D       = zeros(w*h,c) ;
for i=1:c
    bandp = X(:,:,i);
    D(:,i)= bandp(:);
end
M1 =zeros(size(D));  % multiplier for Dx_X-U_x*V_x
M2 =zeros(size(D));  % multiplier for Dy_X-U_y*V_y
M3 =zeros(size(D));  % multiplier for Dz_X-U_z*V_z
Eny_x   = ( abs(psf2otf([+1; -1], [w,h,c])) ).^2  ;
Eny_y   = ( abs(psf2otf([+1, -1], [w,h,c])) ).^2  ;
Eny_z   = ( abs(psf2otf([+1, -1], [h,c,w])) ).^2  ;
Eny_z   =  permute(Eny_z, [3, 1 2]);
determ  =  Eny_x + Eny_y + Eny_z;
%% FFDnet parameter

if c == 3
    load(fullfile('FFDNet_Clip_color.mat'));
else
    load(fullfile('FFDNet_Clip_gray.mat'));
end

net = vl_simplenn_tidy(net);
if useGPU
    net = vl_simplenn_move(net, 'gpu') ;
end
% Out_tSVD_FFDnet.z = {};
process = {};

%% ��ʼ������
r  = [13,13,13];
R = r;
E              = randn(w*h,c);
tv_x           = diff_x(E,sizeD);
tv_x           = reshape(tv_x,[w*h,c]);
[U_x,S_x,V_x]  = svd(tv_x,'econ');
U_x            = U_x(:,1:r(1))*S_x(1:r(1),1:r(1));
V_x            = V_x(:,1:r(1));
% U_y and V_y initial
tv_y           = diff_y(E,sizeD);
tv_y           = reshape(tv_y,[w*h,c]);
[U_y,S_y,V_y]  = svd(tv_y,'econ');
U_y            = U_y(:,1:r(2))*S_y(1:r(2),1:r(2));
V_y            = V_y(:,1:r(2));
% tv_z initial
tv_z           = diff_z(E,sizeD);
tv_z           = reshape(tv_z,[w*h,c]);
[U_z,S_z,V_z]  = svd(tv_z,'econ');
U_z            = U_z(:,1:r(3))*S_z(1:r(3),1:r(3));
V_z            = V_z(:,1:r(3));


for r = 1:maxit
    Xlast = X;
    %% update Y
    XX = Frontal2Lateral(X+Lambda1/beta1);
    [Y] = prox_tnn1(XX,1/beta1,transform); 
    Y = Lateral2Frontal(Y); % each lateral slice is a channel of the image
    %% update Z_x
    input = X+Lambda2/beta2;
    input1=input;
    for jj=1:c
    input=input1(:,:,jj);
    input = single(input); %
    if mod(w,2)==1
        input = cat(1,input, input(end,:)) ;
    end
    if mod(h,2)==1
        input = cat(2,input, input(:,end)) ;
    end
    if useGPU
        input = gpuArray(input);
    end
    max_in = max(input(:));min_in = min(input(:));
    input = (input-min_in)/(max_in-min_in);
%     sigmas = lambda*lambdaInit/beta2/(max_in-min_in);
    sigmas = sigma/(max_in-min_in);
    res    = vl_simplenn(net,input,[],[],'conserveMemory',true,'mode','test');
    output = res(end).x;
    output(output<0)=0;output(output>1)=1;
    output = output*(max_in-min_in)+min_in;
    if mod(w,2)==1
        output = output(1:end-1,:);
    end
    if mod(h,2)==1
        output = output(:,1:end-1);
    end
    if useGPU
        output = gather(output);
    end
    Z(:,:,jj)=output;
    end
%% mode 1
    tmp_x         = reshape(diff_x(W,sizeD),[w*h,c]);
    tmp_x         = tmp_x+M1/mu;
    W_x = 1./(abs(tmp_x*V_x)+eps);
    U_x           = softthre(tmp_x*V_x, W_x*tau/mu);
    U_x  = reshape(U_x ,[w*h,R(1)]);
    tmp_y         = reshape(diff_y(W,sizeD),[w*h,c]);
    tmp_y         = tmp_y+M2/mu;
    W_y = 1./(abs(tmp_y*V_y)+eps);
    U_y           = softthre(tmp_y*V_y, W_y*tau/mu);
    U_y  = reshape(U_y ,[w*h,R(2)]);
    tmp_z         = reshape(diff_z(W,sizeD),[w*h,c]);
    tmp_z         = tmp_z+M3/mu;
    W_z = 1./(abs(tmp_z*V_z)+eps);
    U_z           = softthre(tmp_z*V_z, W_z*tau/mu); 
    U_z  = reshape(U_z ,[w*h,R(3)]);
%% -Update V_x and V_y and V_z
    [u,~,v]       = svd(tmp_x'*U_x,'econ');
    V_x           = u*v';
    [u,~,v]       = svd(tmp_y'*U_y,'econ');
    V_y           = u*v';
    [u,~,v]       = svd(tmp_z'*U_z,'econ');
    V_z           = u*v';
%% Update W 
    diffT_p  = diff_xT(mu*U_x*V_x'-M1,sizeD)+diff_yT(mu*U_y*V_y'-M2,sizeD);
    diffT_p  = diffT_p + diff_zT(mu*U_z*V_z'-M3,sizeD);
    numer1   = reshape( diffT_p + beta3*(X(:)) + Lambda3(:), sizeD);
    z        = real( ifftn( fftn(numer1) ./ (mu*determ + beta3) ) );
    W        = reshape(z,sizeD);  
    %% update X
    X = (beta1*Y+beta2*Z+beta3*W-Lambda1-Lambda2-Lambda3)/(beta1+beta2+beta3);
    X(Omega) = Xmiss(Omega);
    X(X>1) = 1;
    X(X<0) = 0;
    imshow(X(:,:,1))
    %% stopping criterion
    psnrrec(r) = PSNR3D(X,Xtrue);
    relerr(r) = abs(norm(X(:)-Xlast(:)) / norm(Xlast(:)));
    if  mod(r-1,20) ==0 && debug ==1
        process = [process,X-Xtrue];
        fprintf('%d: RSE:   %f \n',r-1,relerr(r));
        fprintf('    PSNR:  %f \n',psnrrec(r));
    end
    reall(r) = abs(norm(X(:)-Xtrue(:)) / norm(Xtrue(:)));
    
    if r > maxit || relerr(r) < tol
        break
    end
    

    
    %% update Lambda
    leq1 = reshape(diff_x(W,sizeD),[w*h,c])- U_x*V_x';
    leq2 = reshape(diff_y(W,sizeD),[w*h,c])- U_y*V_y';
    leq3 = reshape(diff_z(W,sizeD),[w*h,c])- U_z*V_z';
    Lambda1 = Lambda1 + beta1*(X-Y);
     Lambda2 = Lambda2 + beta2*(X-Z);
    Lambda3 = Lambda3 + beta3*(X-W);
    M1 = M1 + mu*leq1;
    M2 = M2 + mu*leq2;
    M3 = M3 + mu*leq3;
    mu = min(max_mu,mu*rho1);
    lambda = rho*lambda;
    sigma = max(minsigma, sigma/rho);
        beta1 = min(maxbeta,beta1*rho);
        beta2 = min(maxbeta,beta2*rho);
        beta3 = min(maxbeta,beta3*rho);
        beta4 = min(maxbeta,beta4*rho);
%         lambda = max(minsigma, 1.05*lambda/rho)
        lambdaInit = max(minsigma, lambdaInit/rho);
        if debug ==2
            fprintf('beta=%.4f\n',beta)
        end

     clear Z_x Z_y Z_z
end

process = [process,X];
Out_tSVD_FFDnet.res = relerr;
Out_tSVD_FFDnet.real = reall;
Out_tSVD_FFDnet.psnr = psnrrec;
Out_tSVD_FFDnet.process = process;
fprintf('total iterations = %d.',r-1);
end


