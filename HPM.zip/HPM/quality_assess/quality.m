function [psnr, ssim, fsim,sam] = quality(imagery1, imagery2)
%==========================================================================
% Evaluates the quality assessment indices for two tensors.
%
% Syntax:
%   [psnr, ssim, fsim] = quality(imagery1, imagery2)
%
% Input:
%   imagery1 - the reference tensor
%   imagery2 - the target tensor

% NOTE: the tensor is a M*N*K array and DYNAMIC RANGE [0, 255]. 

% Output:
%   psnr - Peak Signal-to-Noise Ratio
%   ssim - Structure SIMilarity
%   fsim - Feature SIMilarity

% See also StructureSIM, FeatureSIM
%
% by Yi Peng
% update by Yu-Bang Zheng 11/19/2018
% update by HongHui Xu 11/1/2021
%==========================================================================
Nway = size(imagery1);
psnr = zeros(Nway(3),1);
ssim = psnr;
fsim = psnr;
for i = 1:Nway(3)
    psnr(i) = psnr_index(imagery1(:, :, i), imagery2(:, :, i));
    ssim(i) = ssim_index(imagery1(:, :, i), imagery2(:, :, i));
    fsim(i) = FeatureSIM(imagery1(:, :, i), imagery2(:, :, i));
end
sam= SpectAngMapper(imagery1,imagery2);
sam=sam*180/pi;
psnr = mean(psnr);
ssim = mean(ssim);
fsim = mean(fsim);


