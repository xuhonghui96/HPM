function  [X] =  WNNM( Y, C, NSig)
%     [U,SigmaY,V] = svd(full(Y),'econ');
%      SigmaY=diag(SigmaY);
%     X=zeros(size(Y));
%     PatNum       = size(Y,2);
%       TempC  = C*sqrt(PatNum)*2*NSig^2;
%       r=2;
% %    TempC  = C*NSig^2;
%     if r>0
%       TempC(1:r)=0;
%     end
%     [SigmaX,svp] = ClosedWNNM(SigmaY,TempC,eps); 
%     if svp>=1
%     X =  U(:,1:svp)*diag(SigmaX)*V(:,1:svp)';   
%     end
    r=0;
    [U,SigmaY,V] =   svd(full(Y),'econ');    
    PatNum       = size(Y,2);
    TempC  = C*sqrt(PatNum)*2*NSig^2*ones(size(SigmaY,1),1);
    if r>0
      TempC(1:r)=0;
    end
    [SigmaX,svp] = ClosedTRNM(SigmaY,TempC,eps);                        
    X =  U(:,1:svp)*diag(SigmaX)*V(:,1:svp)';  
return;