clc
clear all
addpath(genpath(cd));
for data_num=[1,2]
    clear img Xhat
switch data_num
    case 1
        load 'akiyo_qcif'
        img=X(:,:,1:100);
        name = 'akiyo' ;
    case 2
        load 'news_qcif'
        img=X(:,:,1:100);
        name = 'news' ;
end
path='C:\Users\admin\Desktop\DP3LRT_1216\results\video\1227\';
Comparison_HPM= 1;
Comparison_HFTNN = 0;
for iter=2:5
    switch iter
        case 1
           SR = 0.05;
        case 2
           SR = 0.1;
        case 3
           SR = 0.2;
        case 4
           SR = 0.3;
        case 5
           SR = 0.5;
    end
%% Observed data
    Input_Image=img;
    Img_Size 	= size(img);
    [m n p]=size(img);
    img        = zeros(Img_Size);
    img    = Input_Image/max(Input_Image(:));
%%
%     P           = round(SR*prod(Img_Size));      % prod���س˻�
%     Omega       = randsample(prod(Img_Size),P);
%     [Omega,~]   = sort(Omega);   % Known = Omega
%     % Missing data
%     Known_Entries       = img(Omega);
%     dimg          = zeros(Img_Size);
%     dimg(Omega)   = Known_Entries;
%     mask=zeros(m,n,p);
%     mask(Omega)   = Known_Entries;
%     mask(find(mask~=0))=1;
%     o=num2str((1-sum(mask(:))/numel(mask))*100,3)
    %%
    clear mask Omega
    mask=rand(m,n,p);
    mask(find(mask<SR))=1;
    mask(find(mask~=1))=0;
    o=num2str((1-sum(mask(:))/numel(mask))*100,3);
    dimg=img.*mask;
    Omega = find(mask==1);
%% ex1
if Comparison_HPM == 1;
    ex1 = 'HPM';
    opts.tol   = 1e-4;
    opts.maxit = 200;
    opts.Xtrue=img;
    opts.debug = 1;
    opts.sigma = 0.01;
    opts.beta1 = 0.1;
    opts.beta2 = 0.1;
    tStart = tic;
    t1= tic;
    [X_HPM, Out_HPM] = admm_HPM_final(dimg, Omega, opts ); 
    t1= toc(t1)
    [PSNR_HPM, SSIM_HPM, FSIM_HPM,SAM_HPM] = quality(img*255, X_HPM*255);
    disp(['PSNR_',ex1,'_',name,'_',num2str(SR) ' = ',num2str(PSNR_HPM)]);
    disp(['SSIM_',ex1,'_',name,'_',num2str(SR) ' = ',num2str(SSIM_HPM)]);
    disp(['FSIM_',ex1,'_',name,'_',num2str(SR) ' = ',num2str(FSIM_HPM)]);
    disp(['SAM_',ex1,'_',name,'_',num2str(SR) ' = ',num2str(SAM_HPM)]);
    save([path,'result_' name '_' num2str(SR) '_' ex1 '.mat'],'X_HPM','PSNR_HPM','SSIM_HPM','FSIM_HPM','SAM_HPM','t1');
end
clear opts
%% 2 HFTNN
if Comparison_HFTNN == 1;
cd '.\compare method\HFTNN'
ex2 = 'HFTNN';
    [dimg1,mask1,r1,r2] = rempat(dimg,mask);
    t2= tic;
    [recon_HFTNN1] = Hankel_keams(dimg1,mask1);
    [recon_HFTNN] = rempat1_3(recon_HFTNN1,r1,r2,p);
    t2= toc(t2)
    cd ..
    cd ..
    [PSNR_HFTNN, SSIM_HFTNN, FSIM_HFTNN,SAM_HFTNN] = quality(img*255, recon_HFTNN*255);
    disp(['PSNR_',ex2,'_',name,'_',num2str(SR) ' = ',num2str(PSNR_HFTNN)]);
    disp(['SSIM_',ex2,'_',name,'_',num2str(SR) ' = ',num2str(SSIM_HFTNN)]);
    disp(['FSIM_',ex2,'_',name,'_',num2str(SR) ' = ',num2str(FSIM_HFTNN)]);
    disp(['SAM_',ex2,'_',name,'_',num2str(SR) ' = ',num2str(SAM_HFTNN)]);
    save([path,'result_' name '_' num2str(SR) '_' ex2 '.mat'],'recon_HFTNN','PSNR_HFTNN','SSIM_HFTNN','FSIM_HFTNN','SAM_HFTNN','t2');
end
clear opts
end
end