function [SigmaX,svp]=ClosedTRNM(SigmaY,C,oureps)
SigmaY = diag(SigmaY);
temp=(SigmaY-oureps).^2-4*(C-oureps*SigmaY);
ind=find (temp>0);
svp=length(ind);
SigmaX=max(SigmaY(ind)-oureps+sqrt(temp(ind)),0)/2;

end